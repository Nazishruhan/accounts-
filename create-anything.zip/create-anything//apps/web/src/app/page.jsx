import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { format } from "date-fns";
import { toast, Toaster } from "sonner";
import {
  PlusCircle,
  TrendingUp,
  TrendingDown,
  Wallet,
  Calendar,
  Filter,
  Search,
  Edit,
  Trash2,
  BarChart3,
  PieChart,
  Settings,
  LogOut,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
} from "recharts";
import useUser from "@/utils/useUser";
import AIAssistant from "@/components/AIAssistant";

const COLORS = [
  "#10B981",
  "#F59E0B",
  "#EF4444",
  "#8B5CF6",
  "#06B6D4",
  "#F97316",
];

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [showAddTransaction, setShowAddTransaction] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [filters, setFilters] = useState({
    type: "",
    category: "",
    startDate: "",
    endDate: "",
    search: "",
  });
  const [currentPage, setCurrentPage] = useState(1);

  const queryClient = useQueryClient();

  // Setup user on first load
  const setupMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/user/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Setup failed");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
    },
  });

  useEffect(() => {
    if (user && !userLoading) {
      setupMutation.mutate();
    }
  }, [user, userLoading]);

  // Fetch transactions
  const { data: transactionsData, isLoading: transactionsLoading } = useQuery({
    queryKey: ["transactions", currentPage, filters],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: "10",
        ...Object.fromEntries(Object.entries(filters).filter(([_, v]) => v)),
      });

      const response = await fetch(`/api/transactions?${params}`);
      if (!response.ok) throw new Error("Failed to fetch transactions");
      return response.json();
    },
    enabled: !!user,
  });

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error("Failed to fetch categories");
      return response.json();
    },
    enabled: !!user,
  });

  // Fetch summary report
  const { data: summaryData } = useQuery({
    queryKey: ["summary", filters.startDate, filters.endDate],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.startDate) params.append("startDate", filters.startDate);
      if (filters.endDate) params.append("endDate", filters.endDate);

      const response = await fetch(`/api/reports/summary?${params}`);
      if (!response.ok) throw new Error("Failed to fetch summary");
      return response.json();
    },
    enabled: !!user,
  });

  // Check if user is admin
  const { data: userRole } = useQuery({
    queryKey: ["userRole"],
    queryFn: async () => {
      const response = await fetch("/api/user/role");
      if (!response.ok) throw new Error("Failed to fetch user role");
      return response.json();
    },
    enabled: !!user,
  });

  // Setup admin mutation
  const setupAdminMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/admin/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to setup admin");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["userRole"]);
      toast.success("Admin setup completed!");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  // Transaction form
  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors },
  } = useForm();
  const watchTransactionType = watch("transaction_type");

  // Add/Edit transaction mutation
  const transactionMutation = useMutation({
    mutationFn: async (data) => {
      const url = editingTransaction
        ? `/api/transactions/${editingTransaction.id}`
        : "/api/transactions";
      const method = editingTransaction ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to save transaction");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["transactions"]);
      queryClient.invalidateQueries(["summary"]);
      setShowAddTransaction(false);
      setEditingTransaction(null);
      reset();
      toast.success(
        editingTransaction ? "Transaction updated!" : "Transaction added!",
      );
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  // Delete transaction mutation
  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/transactions/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to delete transaction");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["transactions"]);
      queryClient.invalidateQueries(["summary"]);
      toast.success("Transaction deleted!");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const onSubmit = (data) => {
    transactionMutation.mutate(data);
  };

  const handleEdit = (transaction) => {
    if (!transaction.is_editable) {
      toast.error("Transaction can only be edited within 7 days");
      return;
    }

    setEditingTransaction(transaction);
    setValue("amount", transaction.amount);
    setValue("description", transaction.description || "");
    setValue("payment_mode", transaction.payment_mode);
    setValue("transaction_type", transaction.transaction_type);
    setValue("category_id", transaction.category_id);
    setValue("transaction_date", transaction.transaction_date);
    setShowAddTransaction(true);
  };

  const handleDelete = (transaction) => {
    if (!transaction.is_editable) {
      toast.error("Transaction can only be deleted within 7 days");
      return;
    }

    if (confirm("Are you sure you want to delete this transaction?")) {
      deleteMutation.mutate(transaction.id);
    }
  };

  const filteredCategories = categories.filter(
    (cat) => !watchTransactionType || cat.type === watchTransactionType,
  );

  // Prepare chart data
  const chartData =
    summaryData?.dailyData?.reduce((acc, item) => {
      const existing = acc.find((d) => d.date === item.date);
      if (existing) {
        existing[item.type] = item.amount;
      } else {
        acc.push({
          date: item.date,
          [item.type]: item.amount,
          [item.type === "income" ? "expense" : "income"]: 0,
        });
      }
      return acc;
    }, []) || [];

  const pieData =
    summaryData?.categoryBreakdown?.expenses?.map((item, index) => ({
      name: item.category,
      value: item.amount,
      color: COLORS[index % COLORS.length],
    })) || [];

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50 flex items-center justify-center p-4">
        <div className="text-center bg-white rounded-2xl p-8 shadow-xl border border-emerald-100">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">
            Expense Tracker
          </h1>
          <p className="text-gray-600 mb-6">
            Track every rupee of your expenses and income
          </p>
          <div className="space-y-4">
            <a
              href="/account/signin"
              className="block w-full bg-emerald-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-emerald-700 transition-colors"
            >
              Sign In
            </a>
            <a
              href="/account/signup"
              className="block w-full border border-emerald-600 text-emerald-600 px-6 py-3 rounded-lg font-medium hover:bg-emerald-50 transition-colors"
            >
              Sign Up
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" />

      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Wallet className="h-8 w-8 text-emerald-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">
                Expense Tracker
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Welcome, {user.email}
              </span>

              {/* Admin Panel Link */}
              {userRole?.role === "admin" && (
                <a
                  href="/admin"
                  className="text-emerald-600 hover:text-emerald-700 text-sm font-medium"
                >
                  Admin Panel
                </a>
              )}

              {/* Setup Admin Button (only show if no admin exists and setup hasn't failed) */}
              {userRole?.role === "user" && (
                <button
                  onClick={() => setupAdminMutation.mutate()}
                  disabled={setupAdminMutation.isPending}
                  className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded hover:bg-blue-200 disabled:opacity-50"
                >
                  {setupAdminMutation.isPending
                    ? "Setting up..."
                    : "Become Admin"}
                </button>
              )}

              <button className="p-2 text-gray-400 hover:text-gray-600">
                <Settings className="h-5 w-5" />
              </button>
              <a
                href="/account/logout"
                className="p-2 text-gray-400 hover:text-gray-600"
              >
                <LogOut className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Summary Cards */}
        {summaryData && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">
                    Total Income
                  </p>
                  <p className="text-2xl font-bold text-gray-900">
                    ₹{summaryData.summary.totalIncome.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center">
                <div className="p-2 bg-red-100 rounded-lg">
                  <TrendingDown className="h-6 w-6 text-red-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">
                    Total Expenses
                  </p>
                  <p className="text-2xl font-bold text-gray-900">
                    ₹{summaryData.summary.totalExpenses.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center">
                <div
                  className={`p-2 rounded-lg ${summaryData.summary.balance >= 0 ? "bg-emerald-100" : "bg-red-100"}`}
                >
                  <Wallet
                    className={`h-6 w-6 ${summaryData.summary.balance >= 0 ? "text-emerald-600" : "text-red-600"}`}
                  />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Balance</p>
                  <p
                    className={`text-2xl font-bold ${summaryData.summary.balance >= 0 ? "text-emerald-600" : "text-red-600"}`}
                  >
                    ₹{summaryData.summary.balance.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Charts */}
        {summaryData && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Line Chart */}
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <BarChart3 className="h-5 w-5 mr-2" />
                Daily Trends
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`₹${value}`, ""]} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="income"
                      stroke="#10B981"
                      strokeWidth={2}
                    />
                    <Line
                      type="monotone"
                      dataKey="expense"
                      stroke="#EF4444"
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Pie Chart */}
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <PieChart className="h-5 w-5 mr-2" />
                Expense Categories
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) =>
                        `${name} ${(percent * 100).toFixed(0)}%`
                      }
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`₹${value}`, "Amount"]} />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* Transactions Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 sm:mb-0">
                Recent Transactions
              </h2>
              <button
                onClick={() => {
                  setEditingTransaction(null);
                  reset();
                  setShowAddTransaction(true);
                }}
                className="inline-flex items-center px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
              >
                <PlusCircle className="h-5 w-5 mr-2" />
                Add Transaction
              </button>
            </div>

            {/* Filters */}
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              <select
                value={filters.type}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, type: e.target.value }))
                }
                className="rounded-lg border border-gray-300 px-3 py-2 text-sm"
              >
                <option value="">All Types</option>
                <option value="income">Income</option>
                <option value="expense">Expense</option>
              </select>

              <select
                value={filters.category}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, category: e.target.value }))
                }
                className="rounded-lg border border-gray-300 px-3 py-2 text-sm"
              >
                <option value="">All Categories</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>

              <input
                type="date"
                value={filters.startDate}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, startDate: e.target.value }))
                }
                className="rounded-lg border border-gray-300 px-3 py-2 text-sm"
                placeholder="Start Date"
              />

              <input
                type="date"
                value={filters.endDate}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, endDate: e.target.value }))
                }
                className="rounded-lg border border-gray-300 px-3 py-2 text-sm"
                placeholder="End Date"
              />

              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  value={filters.search}
                  onChange={(e) =>
                    setFilters((prev) => ({ ...prev, search: e.target.value }))
                  }
                  placeholder="Search transactions..."
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg text-sm"
                />
              </div>
            </div>
          </div>

          {/* Transactions List */}
          <div className="p-6">
            {transactionsLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Loading transactions...</p>
              </div>
            ) : transactionsData?.transactions?.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-600">No transactions found</p>
              </div>
            ) : (
              <div className="space-y-4">
                {transactionsData?.transactions?.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-gray-900">
                            {transaction.category_name}
                          </p>
                          <p className="text-sm text-gray-600">
                            {transaction.description || "No description"}
                          </p>
                          <p className="text-xs text-gray-500">
                            {format(
                              new Date(transaction.transaction_date),
                              "MMM dd, yyyy",
                            )}{" "}
                            • {transaction.payment_mode}
                          </p>
                        </div>
                        <div className="text-right">
                          <p
                            className={`text-lg font-semibold ${
                              transaction.transaction_type === "income"
                                ? "text-green-600"
                                : "text-red-600"
                            }`}
                          >
                            {transaction.transaction_type === "income"
                              ? "+"
                              : "-"}
                            ₹{parseFloat(transaction.amount).toLocaleString()}
                          </p>
                          <div className="flex items-center space-x-2 mt-1">
                            {transaction.is_editable && (
                              <>
                                <button
                                  onClick={() => handleEdit(transaction)}
                                  className="p-1 text-gray-400 hover:text-emerald-600"
                                >
                                  <Edit className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => handleDelete(transaction)}
                                  className="p-1 text-gray-400 hover:text-red-600"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Pagination */}
            {transactionsData?.pagination &&
              transactionsData.pagination.totalPages > 1 && (
                <div className="flex justify-center mt-6">
                  <div className="flex space-x-2">
                    {Array.from(
                      { length: transactionsData.pagination.totalPages },
                      (_, i) => i + 1,
                    ).map((page) => (
                      <button
                        key={page}
                        onClick={() => setCurrentPage(page)}
                        className={`px-3 py-2 rounded-lg text-sm ${
                          page === currentPage
                            ? "bg-emerald-600 text-white"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                        }`}
                      >
                        {page}
                      </button>
                    ))}
                  </div>
                </div>
              )}
          </div>
        </div>
      </div>

      {/* Add/Edit Transaction Modal */}
      {showAddTransaction && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {editingTransaction ? "Edit Transaction" : "Add Transaction"}
            </h3>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Type
                </label>
                <select
                  {...register("transaction_type", {
                    required: "Type is required",
                  })}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2"
                >
                  <option value="">Select type</option>
                  <option value="income">Income</option>
                  <option value="expense">Expense</option>
                </select>
                {errors.transaction_type && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.transaction_type.message}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  {...register("category_id", {
                    required: "Category is required",
                  })}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2"
                >
                  <option value="">Select category</option>
                  {filteredCategories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
                {errors.category_id && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.category_id.message}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Amount (₹)
                </label>
                <input
                  type="number"
                  step="0.01"
                  {...register("amount", {
                    required: "Amount is required",
                    min: { value: 0.01, message: "Amount must be positive" },
                  })}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2"
                  placeholder="0.00"
                />
                {errors.amount && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.amount.message}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Payment Mode
                </label>
                <select
                  {...register("payment_mode", {
                    required: "Payment mode is required",
                  })}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2"
                >
                  <option value="">Select payment mode</option>
                  <option value="cash">Cash</option>
                  <option value="upi">UPI</option>
                  <option value="card">Card</option>
                  <option value="bank_transfer">Bank Transfer</option>
                  <option value="other">Other</option>
                </select>
                {errors.payment_mode && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.payment_mode.message}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  {...register("transaction_date", {
                    required: "Date is required",
                  })}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2"
                  defaultValue={new Date().toISOString().split("T")[0]}
                />
                {errors.transaction_date && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.transaction_date.message}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description (Optional)
                </label>
                <textarea
                  {...register("description")}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2"
                  rows="2"
                  placeholder="Add a note..."
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddTransaction(false);
                    setEditingTransaction(null);
                    reset();
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={transactionMutation.isPending}
                  className="flex-1 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50"
                >
                  {transactionMutation.isPending
                    ? "Saving..."
                    : editingTransaction
                      ? "Update"
                      : "Add"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* AI Assistant - Floating Chat Widget */}
      <AIAssistant />
    </div>
  );
}

export default MainComponent;
