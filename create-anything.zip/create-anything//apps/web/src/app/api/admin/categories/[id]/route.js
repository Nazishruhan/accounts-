import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function DELETE(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userRole = await sql`
      SELECT role FROM user_roles WHERE user_id = ${session.user.id}
    `;

    if (userRole.length === 0 || userRole[0].role !== 'admin') {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    const { id } = params;

    // Check if category exists and is not default
    const category = await sql`
      SELECT id, is_default FROM categories WHERE id = ${id}
    `;

    if (category.length === 0) {
      return Response.json({ error: "Category not found" }, { status: 404 });
    }

    if (category[0].is_default) {
      return Response.json({ error: "Cannot delete default categories" }, { status: 403 });
    }

    // Check if category is being used in transactions
    const usageCheck = await sql`
      SELECT COUNT(*) as count FROM transactions WHERE category_id = ${id}
    `;

    if (parseInt(usageCheck[0].count) > 0) {
      return Response.json({ 
        error: "Cannot delete category that is being used in transactions" 
      }, { status: 409 });
    }

    // Delete the category
    const result = await sql`
      DELETE FROM categories WHERE id = ${id}
      RETURNING id
    `;

    if (result.length === 0) {
      return Response.json({ error: "Category not found" }, { status: 404 });
    }

    return Response.json({ message: "Category deleted successfully" });

  } catch (error) {
    console.error('Error deleting admin category:', error);
    return Response.json({ error: "Failed to delete category" }, { status: 500 });
  }
}