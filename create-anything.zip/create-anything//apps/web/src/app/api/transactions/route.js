import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '20');
    const type = url.searchParams.get('type'); // 'expense' or 'income'
    const category = url.searchParams.get('category');
    const startDate = url.searchParams.get('startDate');
    const endDate = url.searchParams.get('endDate');
    const search = url.searchParams.get('search');

    const offset = (page - 1) * limit;

    // Build dynamic query
    let whereConditions = ['t.user_id = $1'];
    let params = [session.user.id];
    let paramCount = 1;

    if (type) {
      paramCount++;
      whereConditions.push(`t.transaction_type = $${paramCount}`);
      params.push(type);
    }

    if (category) {
      paramCount++;
      whereConditions.push(`t.category_id = $${paramCount}`);
      params.push(category);
    }

    if (startDate) {
      paramCount++;
      whereConditions.push(`t.transaction_date >= $${paramCount}`);
      params.push(startDate);
    }

    if (endDate) {
      paramCount++;
      whereConditions.push(`t.transaction_date <= $${paramCount}`);
      params.push(endDate);
    }

    if (search) {
      paramCount++;
      whereConditions.push(`(LOWER(t.description) LIKE LOWER($${paramCount}) OR LOWER(c.name) LIKE LOWER($${paramCount}))`);
      params.push(`%${search}%`);
    }

    const whereClause = whereConditions.join(' AND ');

    // Get transactions with category info
    const query = `
      SELECT 
        t.id,
        t.amount,
        t.description,
        t.payment_mode,
        t.transaction_type,
        t.transaction_date,
        t.created_at,
        t.updated_at,
        EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - t.created_at)) / 86400 <= 7 as is_editable,
        c.name as category_name,
        c.id as category_id
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      WHERE ${whereClause}
      ORDER BY t.transaction_date DESC, t.created_at DESC
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `;

    params.push(limit, offset);

    const transactions = await sql(query, params);

    // Get total count for pagination
    const countQuery = `
      SELECT COUNT(*) as total
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      WHERE ${whereClause}
    `;

    const countResult = await sql(countQuery, params.slice(0, -2));
    const total = parseInt(countResult[0].total);

    return Response.json({
      transactions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching transactions:', error);
    return Response.json({ error: "Failed to fetch transactions" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { amount, description, payment_mode, transaction_type, category_id, transaction_date } = body;

    // Validate required fields
    if (!amount || !payment_mode || !transaction_type || !category_id) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Validate amount is positive
    if (parseFloat(amount) <= 0) {
      return Response.json({ error: "Amount must be positive" }, { status: 400 });
    }

    // Validate payment mode
    const validPaymentModes = ['cash', 'upi', 'card', 'bank_transfer', 'other'];
    if (!validPaymentModes.includes(payment_mode)) {
      return Response.json({ error: "Invalid payment mode" }, { status: 400 });
    }

    // Validate transaction type
    if (!['expense', 'income'].includes(transaction_type)) {
      return Response.json({ error: "Invalid transaction type" }, { status: 400 });
    }

    // Verify category belongs to user or is default
    const categoryCheck = await sql`
      SELECT id, type FROM categories 
      WHERE id = ${category_id} 
      AND (user_id = ${session.user.id} OR is_default = true)
      AND type = ${transaction_type}
    `;

    if (categoryCheck.length === 0) {
      return Response.json({ error: "Invalid category" }, { status: 400 });
    }

    // Insert transaction
    const result = await sql`
      INSERT INTO transactions (
        user_id, category_id, amount, description, payment_mode, 
        transaction_type, transaction_date
      ) VALUES (
        ${session.user.id}, ${category_id}, ${amount}, ${description || null}, 
        ${payment_mode}, ${transaction_type}, ${transaction_date || new Date().toISOString().split('T')[0]}
      )
      RETURNING *
    `;

    return Response.json(result[0], { status: 201 });

  } catch (error) {
    console.error('Error creating transaction:', error);
    return Response.json({ error: "Failed to create transaction" }, { status: 500 });
  }
}