import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const period = url.searchParams.get('period') || 'monthly'; // monthly, weekly, yearly
    const startDate = url.searchParams.get('startDate');
    const endDate = url.searchParams.get('endDate');

    let dateFilter = '';
    let params = [session.user.id];
    let paramCount = 1;

    if (startDate && endDate) {
      paramCount++;
      dateFilter = `AND transaction_date BETWEEN $${paramCount} AND $${paramCount + 1}`;
      params.push(startDate, endDate);
      paramCount++;
    } else {
      // Default to current month if no dates provided
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
      
      paramCount++;
      dateFilter = `AND transaction_date BETWEEN $${paramCount} AND $${paramCount + 1}`;
      params.push(firstDay, lastDay);
      paramCount++;
    }

    // Get total income and expenses
    const totalsQuery = `
      SELECT 
        transaction_type,
        SUM(amount) as total
      FROM transactions 
      WHERE user_id = $1 ${dateFilter}
      GROUP BY transaction_type
    `;

    const totals = await sql(totalsQuery, params);

    // Get category-wise breakdown
    const categoryQuery = `
      SELECT 
        c.name as category_name,
        c.type as category_type,
        SUM(t.amount) as total,
        COUNT(t.id) as transaction_count
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      WHERE t.user_id = $1 ${dateFilter}
      GROUP BY c.id, c.name, c.type
      ORDER BY total DESC
    `;

    const categoryBreakdown = await sql(categoryQuery, params);

    // Get daily totals for chart data
    const dailyQuery = `
      SELECT 
        transaction_date,
        transaction_type,
        SUM(amount) as daily_total
      FROM transactions 
      WHERE user_id = $1 ${dateFilter}
      GROUP BY transaction_date, transaction_type
      ORDER BY transaction_date ASC
    `;

    const dailyData = await sql(dailyQuery, params);

    // Get payment mode breakdown
    const paymentModeQuery = `
      SELECT 
        payment_mode,
        transaction_type,
        SUM(amount) as total,
        COUNT(id) as transaction_count
      FROM transactions 
      WHERE user_id = $1 ${dateFilter}
      GROUP BY payment_mode, transaction_type
      ORDER BY total DESC
    `;

    const paymentModeBreakdown = await sql(paymentModeQuery, params);

    // Calculate summary
    const totalIncome = totals.find(t => t.transaction_type === 'income')?.total || 0;
    const totalExpenses = totals.find(t => t.transaction_type === 'expense')?.total || 0;
    const balance = parseFloat(totalIncome) - parseFloat(totalExpenses);

    // Group category breakdown by type
    const expenseCategories = categoryBreakdown.filter(c => c.category_type === 'expense');
    const incomeCategories = categoryBreakdown.filter(c => c.category_type === 'income');

    // Group payment mode breakdown by type
    const expensePaymentModes = paymentModeBreakdown.filter(p => p.transaction_type === 'expense');
    const incomePaymentModes = paymentModeBreakdown.filter(p => p.transaction_type === 'income');

    return Response.json({
      summary: {
        totalIncome: parseFloat(totalIncome),
        totalExpenses: parseFloat(totalExpenses),
        balance,
        period
      },
      categoryBreakdown: {
        expenses: expenseCategories.map(c => ({
          category: c.category_name,
          amount: parseFloat(c.total),
          count: parseInt(c.transaction_count)
        })),
        income: incomeCategories.map(c => ({
          category: c.category_name,
          amount: parseFloat(c.total),
          count: parseInt(c.transaction_count)
        }))
      },
      paymentModeBreakdown: {
        expenses: expensePaymentModes.map(p => ({
          mode: p.payment_mode,
          amount: parseFloat(p.total),
          count: parseInt(p.transaction_count)
        })),
        income: incomePaymentModes.map(p => ({
          mode: p.payment_mode,
          amount: parseFloat(p.total),
          count: parseInt(p.transaction_count)
        }))
      },
      dailyData: dailyData.map(d => ({
        date: d.transaction_date,
        type: d.transaction_type,
        amount: parseFloat(d.daily_total)
      }))
    });

  } catch (error) {
    console.error('Error generating summary report:', error);
    return Response.json({ error: "Failed to generate summary report" }, { status: 500 });
  }
}