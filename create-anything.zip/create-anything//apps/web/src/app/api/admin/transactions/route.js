import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userRole = await sql`
      SELECT role FROM user_roles WHERE user_id = ${session.user.id}
    `;

    if (userRole.length === 0 || userRole[0].role !== 'admin') {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '50');
    const offset = (page - 1) * limit;

    // Get all transactions with user and category info
    const transactions = await sql`
      SELECT 
        t.id,
        t.amount,
        t.description,
        t.payment_mode,
        t.transaction_type,
        t.transaction_date,
        t.created_at,
        c.name as category_name,
        u.email as user_email
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      JOIN auth_users u ON t.user_id = u.id
      ORDER BY t.created_at DESC
      LIMIT ${limit} OFFSET ${offset}
    `;

    return Response.json(transactions.map(t => ({
      ...t,
      amount: parseFloat(t.amount)
    })));

  } catch (error) {
    console.error('Error fetching admin transactions:', error);
    return Response.json({ error: "Failed to fetch admin transactions" }, { status: 500 });
  }
}