import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userRole = await sql`
      SELECT role FROM user_roles WHERE user_id = ${session.user.id}
    `;

    if (userRole.length === 0 || userRole[0].role !== 'admin') {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    // Get all categories with usage count
    const categories = await sql`
      SELECT 
        c.id,
        c.name,
        c.type,
        c.is_default,
        c.user_id,
        c.created_at,
        COUNT(t.id) as usage_count
      FROM categories c
      LEFT JOIN transactions t ON c.id = t.category_id
      GROUP BY c.id, c.name, c.type, c.is_default, c.user_id, c.created_at
      ORDER BY c.is_default DESC, c.type ASC, c.name ASC
    `;

    return Response.json(categories.map(c => ({
      ...c,
      usage_count: parseInt(c.usage_count)
    })));

  } catch (error) {
    console.error('Error fetching admin categories:', error);
    return Response.json({ error: "Failed to fetch admin categories" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userRole = await sql`
      SELECT role FROM user_roles WHERE user_id = ${session.user.id}
    `;

    if (userRole.length === 0 || userRole[0].role !== 'admin') {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    const body = await request.json();
    const { name, type } = body;

    // Validate required fields
    if (!name || !type) {
      return Response.json({ error: "Name and type are required" }, { status: 400 });
    }

    // Validate type
    if (!['expense', 'income'].includes(type)) {
      return Response.json({ error: "Type must be 'expense' or 'income'" }, { status: 400 });
    }

    // Check if default category already exists
    const existingCategory = await sql`
      SELECT id FROM categories 
      WHERE name = ${name} AND type = ${type} AND is_default = true
    `;

    if (existingCategory.length > 0) {
      return Response.json({ error: "Default category already exists" }, { status: 409 });
    }

    // Insert new default category
    const result = await sql`
      INSERT INTO categories (name, type, is_default, user_id)
      VALUES (${name}, ${type}, true, NULL)
      RETURNING *
    `;

    return Response.json(result[0], { status: 201 });

  } catch (error) {
    console.error('Error creating admin category:', error);
    return Response.json({ error: "Failed to create category" }, { status: 500 });
  }
}