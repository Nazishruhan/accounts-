import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user already has setup completed
    const existingPrefs = await sql`
      SELECT id FROM user_preferences WHERE user_id = ${session.user.id}
    `;

    const existingRole = await sql`
      SELECT id FROM user_roles WHERE user_id = ${session.user.id}
    `;

    // Create user preferences if they don't exist
    if (existingPrefs.length === 0) {
      await sql`
        INSERT INTO user_preferences (user_id, currency, budget_limit, budget_period, notifications_enabled)
        VALUES (${session.user.id}, 'INR', NULL, 'monthly', true)
      `;
    }

    // Create user role if it doesn't exist (default to 'user')
    if (existingRole.length === 0) {
      await sql`
        INSERT INTO user_roles (user_id, role)
        VALUES (${session.user.id}, 'user')
      `;
    }

    // Copy default categories for the user (so they can customize them)
    const userCategories = await sql`
      SELECT id FROM categories WHERE user_id = ${session.user.id}
    `;

    if (userCategories.length === 0) {
      // Get default categories
      const defaultCategories = await sql`
        SELECT name, type FROM categories WHERE is_default = true
      `;

      // Insert user-specific copies of default categories
      for (const category of defaultCategories) {
        await sql`
          INSERT INTO categories (name, type, user_id, is_default)
          VALUES (${category.name}, ${category.type}, ${session.user.id}, false)
        `;
      }
    }

    return Response.json({ message: "User setup completed successfully" });

  } catch (error) {
    console.error('Error setting up user:', error);
    return Response.json({ error: "Failed to setup user" }, { status: 500 });
  }
}