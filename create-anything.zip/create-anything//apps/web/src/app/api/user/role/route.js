import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get user role
    const userRole = await sql`
      SELECT role FROM user_roles WHERE user_id = ${session.user.id}
    `;

    if (userRole.length === 0) {
      // Create default user role if it doesn't exist
      await sql`
        INSERT INTO user_roles (user_id, role)
        VALUES (${session.user.id}, 'user')
      `;
      return Response.json({ role: 'user' });
    }

    return Response.json({ role: userRole[0].role });

  } catch (error) {
    console.error('Error fetching user role:', error);
    return Response.json({ error: "Failed to fetch user role" }, { status: 500 });
  }
}