import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if any admin exists
    const existingAdmins = await sql`
      SELECT COUNT(*) as count FROM user_roles WHERE role = 'admin'
    `;

    if (parseInt(existingAdmins[0].count) > 0) {
      return Response.json({ error: "Admin already exists" }, { status: 409 });
    }

    // Make the current user an admin
    const existingRole = await sql`
      SELECT id FROM user_roles WHERE user_id = ${session.user.id}
    `;

    if (existingRole.length > 0) {
      // Update existing role
      await sql`
        UPDATE user_roles 
        SET role = 'admin' 
        WHERE user_id = ${session.user.id}
      `;
    } else {
      // Create new admin role
      await sql`
        INSERT INTO user_roles (user_id, role)
        VALUES (${session.user.id}, 'admin')
      `;
    }

    return Response.json({ message: "Admin setup completed successfully" });

  } catch (error) {
    console.error('Error setting up admin:', error);
    return Response.json({ error: "Failed to setup admin" }, { status: 500 });
  }
}