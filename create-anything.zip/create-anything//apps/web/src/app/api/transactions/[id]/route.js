import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;

    const result = await sql`
      SELECT 
        t.id,
        t.amount,
        t.description,
        t.payment_mode,
        t.transaction_type,
        t.transaction_date,
        t.created_at,
        t.updated_at,
        EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - t.created_at)) / 86400 <= 7 as is_editable,
        c.name as category_name,
        c.id as category_id
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      WHERE t.id = ${id} AND t.user_id = ${session.user.id}
    `;

    if (result.length === 0) {
      return Response.json({ error: "Transaction not found" }, { status: 404 });
    }

    return Response.json(result[0]);

  } catch (error) {
    console.error('Error fetching transaction:', error);
    return Response.json({ error: "Failed to fetch transaction" }, { status: 500 });
  }
}

export async function PUT(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;
    const body = await request.json();

    // Check if transaction exists and is editable
    const existingTransaction = await sql`
      SELECT 
        id,
        EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - created_at)) / 86400 <= 7 as is_editable
      FROM transactions 
      WHERE id = ${id} AND user_id = ${session.user.id}
    `;

    if (existingTransaction.length === 0) {
      return Response.json({ error: "Transaction not found" }, { status: 404 });
    }

    if (!existingTransaction[0].is_editable) {
      return Response.json({ error: "Transaction can only be edited within 7 days of creation" }, { status: 403 });
    }

    // Build update query dynamically
    const updateFields = [];
    const updateValues = [];
    let paramCount = 0;

    if (body.amount !== undefined) {
      if (parseFloat(body.amount) <= 0) {
        return Response.json({ error: "Amount must be positive" }, { status: 400 });
      }
      paramCount++;
      updateFields.push(`amount = $${paramCount}`);
      updateValues.push(body.amount);
    }

    if (body.description !== undefined) {
      paramCount++;
      updateFields.push(`description = $${paramCount}`);
      updateValues.push(body.description);
    }

    if (body.payment_mode !== undefined) {
      const validPaymentModes = ['cash', 'upi', 'card', 'bank_transfer', 'other'];
      if (!validPaymentModes.includes(body.payment_mode)) {
        return Response.json({ error: "Invalid payment mode" }, { status: 400 });
      }
      paramCount++;
      updateFields.push(`payment_mode = $${paramCount}`);
      updateValues.push(body.payment_mode);
    }

    if (body.category_id !== undefined) {
      // Get current transaction type to validate category
      const currentTransaction = await sql`
        SELECT transaction_type FROM transactions WHERE id = ${id}
      `;
      
      const categoryCheck = await sql`
        SELECT id FROM categories 
        WHERE id = ${body.category_id} 
        AND (user_id = ${session.user.id} OR is_default = true)
        AND type = ${currentTransaction[0].transaction_type}
      `;

      if (categoryCheck.length === 0) {
        return Response.json({ error: "Invalid category" }, { status: 400 });
      }

      paramCount++;
      updateFields.push(`category_id = $${paramCount}`);
      updateValues.push(body.category_id);
    }

    if (body.transaction_date !== undefined) {
      paramCount++;
      updateFields.push(`transaction_date = $${paramCount}`);
      updateValues.push(body.transaction_date);
    }

    if (updateFields.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    // Add updated_at
    paramCount++;
    updateFields.push(`updated_at = $${paramCount}`);
    updateValues.push(new Date().toISOString());

    // Add WHERE clause parameters
    paramCount++;
    updateValues.push(id);
    paramCount++;
    updateValues.push(session.user.id);

    const updateQuery = `
      UPDATE transactions 
      SET ${updateFields.join(', ')}
      WHERE id = $${paramCount - 1} AND user_id = $${paramCount}
      RETURNING *
    `;

    const result = await sql(updateQuery, updateValues);

    return Response.json(result[0]);

  } catch (error) {
    console.error('Error updating transaction:', error);
    return Response.json({ error: "Failed to update transaction" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;

    // Check if user is admin or if transaction is editable
    const userRole = await sql`
      SELECT role FROM user_roles WHERE user_id = ${session.user.id}
    `;

    const isAdmin = userRole.length > 0 && userRole[0].role === 'admin';

    if (!isAdmin) {
      // Check if transaction is editable for regular users
      const transactionCheck = await sql`
        SELECT 
          id,
          EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - created_at)) / 86400 <= 7 as is_editable
        FROM transactions 
        WHERE id = ${id} AND user_id = ${session.user.id}
      `;

      if (transactionCheck.length === 0) {
        return Response.json({ error: "Transaction not found" }, { status: 404 });
      }

      if (!transactionCheck[0].is_editable) {
        return Response.json({ error: "Transaction can only be deleted within 7 days of creation" }, { status: 403 });
      }
    }

    const result = await sql`
      DELETE FROM transactions 
      WHERE id = ${id} AND user_id = ${session.user.id}
      RETURNING id
    `;

    if (result.length === 0) {
      return Response.json({ error: "Transaction not found" }, { status: 404 });
    }

    return Response.json({ message: "Transaction deleted successfully" });

  } catch (error) {
    console.error('Error deleting transaction:', error);
    return Response.json({ error: "Failed to delete transaction" }, { status: 500 });
  }
}