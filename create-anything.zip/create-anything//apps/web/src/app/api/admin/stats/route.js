import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userRole = await sql`
      SELECT role FROM user_roles WHERE user_id = ${session.user.id}
    `;

    if (userRole.length === 0 || userRole[0].role !== 'admin') {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    // Get total users
    const totalUsersResult = await sql`
      SELECT COUNT(*) as count FROM auth_users
    `;
    const totalUsers = parseInt(totalUsersResult[0].count);

    // Get total income and expenses
    const totalsResult = await sql`
      SELECT 
        transaction_type,
        SUM(amount) as total
      FROM transactions 
      GROUP BY transaction_type
    `;

    const totalIncome = totalsResult.find(t => t.transaction_type === 'income')?.total || 0;
    const totalExpenses = totalsResult.find(t => t.transaction_type === 'expense')?.total || 0;

    // Get total transactions
    const totalTransactionsResult = await sql`
      SELECT COUNT(*) as count FROM transactions
    `;
    const totalTransactions = parseInt(totalTransactionsResult[0].count);

    // Get recent transactions with user info
    const recentTransactions = await sql`
      SELECT 
        t.id,
        t.amount,
        t.description,
        t.transaction_type,
        t.created_at,
        c.name as category_name,
        u.email as user_email
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      JOIN auth_users u ON t.user_id = u.id
      ORDER BY t.created_at DESC
      LIMIT 10
    `;

    return Response.json({
      totalUsers,
      totalIncome: parseFloat(totalIncome),
      totalExpenses: parseFloat(totalExpenses),
      totalTransactions,
      recentTransactions: recentTransactions.map(t => ({
        ...t,
        amount: parseFloat(t.amount)
      }))
    });

  } catch (error) {
    console.error('Error fetching admin stats:', error);
    return Response.json({ error: "Failed to fetch admin stats" }, { status: 500 });
  }
}