import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const type = url.searchParams.get('type'); // 'expense' or 'income'

    let whereClause = '(user_id = $1 OR is_default = true)';
    let params = [session.user.id];

    if (type) {
      whereClause += ' AND type = $2';
      params.push(type);
    }

    const query = `
      SELECT id, name, type, is_default, user_id, created_at
      FROM categories 
      WHERE ${whereClause}
      ORDER BY is_default DESC, name ASC
    `;

    const categories = await sql(query, params);

    return Response.json(categories);

  } catch (error) {
    console.error('Error fetching categories:', error);
    return Response.json({ error: "Failed to fetch categories" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { name, type } = body;

    // Validate required fields
    if (!name || !type) {
      return Response.json({ error: "Name and type are required" }, { status: 400 });
    }

    // Validate type
    if (!['expense', 'income'].includes(type)) {
      return Response.json({ error: "Type must be 'expense' or 'income'" }, { status: 400 });
    }

    // Check if category already exists for this user
    const existingCategory = await sql`
      SELECT id FROM categories 
      WHERE name = ${name} AND type = ${type} AND user_id = ${session.user.id}
    `;

    if (existingCategory.length > 0) {
      return Response.json({ error: "Category already exists" }, { status: 409 });
    }

    // Insert new category
    const result = await sql`
      INSERT INTO categories (name, type, user_id, is_default)
      VALUES (${name}, ${type}, ${session.user.id}, false)
      RETURNING *
    `;

    return Response.json(result[0], { status: 201 });

  } catch (error) {
    console.error('Error creating category:', error);
    return Response.json({ error: "Failed to create category" }, { status: 500 });
  }
}