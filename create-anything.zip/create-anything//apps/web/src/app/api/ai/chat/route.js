import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { message, conversationHistory = [] } = body;

    if (!message) {
      return Response.json({ error: "Message is required" }, { status: 400 });
    }

    // Fetch user's spending data (last 30 days for context)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const formattedDate = thirtyDaysAgo.toISOString().split("T")[0];

    // Get summary statistics
    const summary = await sql`
      SELECT 
        transaction_type,
        SUM(amount) as total
      FROM transactions
      WHERE user_id = ${session.user.id}
        AND transaction_date >= ${formattedDate}
      GROUP BY transaction_type
    `;

    const totalIncome =
      summary.find((s) => s.transaction_type === "income")?.total || 0;
    const totalExpenses =
      summary.find((s) => s.transaction_type === "expense")?.total || 0;
    const balance = parseFloat(totalIncome) - parseFloat(totalExpenses);

    // Get category breakdown for expenses
    const categoryBreakdown = await sql`
      SELECT 
        c.name as category,
        c.type,
        SUM(t.amount) as total,
        COUNT(*) as count
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      WHERE t.user_id = ${session.user.id}
        AND t.transaction_date >= ${formattedDate}
      GROUP BY c.id, c.name, c.type
      ORDER BY total DESC
      LIMIT 10
    `;

    // Get recent transactions
    const recentTransactions = await sql`
      SELECT 
        t.amount,
        t.description,
        t.payment_mode,
        t.transaction_type,
        t.transaction_date,
        c.name as category
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      WHERE t.user_id = ${session.user.id}
        AND t.transaction_date >= ${formattedDate}
      ORDER BY t.transaction_date DESC
      LIMIT 20
    `;

    // Get payment mode distribution
    const paymentModes = await sql`
      SELECT 
        payment_mode,
        COUNT(*) as count,
        SUM(amount) as total
      FROM transactions
      WHERE user_id = ${session.user.id}
        AND transaction_date >= ${formattedDate}
      GROUP BY payment_mode
      ORDER BY total DESC
    `;

    // Build context for AI
    const userDataContext = `
You are a helpful financial assistant for an expense tracking app. The user is asking about their spending habits.

Here is the user's financial data for the last 30 days:

SUMMARY:
- Total Income: ₹${parseFloat(totalIncome).toLocaleString()}
- Total Expenses: ₹${parseFloat(totalExpenses).toLocaleString()}
- Current Balance: ₹${balance.toLocaleString()}

TOP SPENDING CATEGORIES:
${categoryBreakdown
  .filter((c) => c.type === "expense")
  .map(
    (c) =>
      `- ${c.category}: ₹${parseFloat(c.total).toLocaleString()} (${c.count} transactions)`,
  )
  .join("\n")}

INCOME SOURCES:
${categoryBreakdown
  .filter((c) => c.type === "income")
  .map(
    (c) =>
      `- ${c.category}: ₹${parseFloat(c.total).toLocaleString()} (${c.count} transactions)`,
  )
  .join("\n")}

PAYMENT METHODS USED:
${paymentModes
  .map(
    (p) =>
      `- ${p.payment_mode}: ₹${parseFloat(p.total).toLocaleString()} (${p.count} transactions)`,
  )
  .join("\n")}

RECENT TRANSACTIONS (Sample):
${recentTransactions
  .slice(0, 10)
  .map(
    (t) =>
      `- ${t.transaction_date}: ${t.transaction_type === "income" ? "+" : "-"}₹${parseFloat(t.amount).toLocaleString()} - ${t.category} ${t.description ? `(${t.description})` : ""}`,
  )
  .join("\n")}

Guidelines:
1. Answer questions directly and concisely
2. Use actual numbers from the data above
3. Provide insights and suggestions when relevant
4. Keep responses friendly and helpful
5. If asked about data outside the 30-day window, mention that you only have access to the last 30 days
6. Format currency amounts with ₹ symbol and use Indian number formatting
7. Don't make up information - only use the data provided above
8. If the user asks about future predictions, make it clear it's just an estimate based on current trends
`;

    // Prepare messages for ChatGPT
    const messages = [
      {
        role: "system",
        content: userDataContext,
      },
      ...conversationHistory,
      {
        role: "user",
        content: message,
      },
    ];

    // Call ChatGPT API
    const aiResponse = await fetch("/integrations/chat-gpt/conversationgpt4", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: messages,
        stream: body.stream || false,
      }),
    });

    if (!aiResponse.ok) {
      throw new Error("AI service unavailable");
    }

    // If streaming, return the stream directly
    if (body.stream) {
      return new Response(aiResponse.body, {
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
          Connection: "keep-alive",
        },
      });
    }

    // Otherwise return the complete response
    const aiData = await aiResponse.json();
    const assistantMessage =
      aiData.choices?.[0]?.message?.content ||
      aiData.result ||
      "I'm sorry, I couldn't process that request.";

    return Response.json({
      message: assistantMessage,
      data: {
        summary: {
          totalIncome: parseFloat(totalIncome),
          totalExpenses: parseFloat(totalExpenses),
          balance: balance,
        },
      },
    });
  } catch (error) {
    console.error("Error in AI chat:", error);
    return Response.json(
      {
        error: "Failed to process chat message",
        message:
          "I'm having trouble connecting right now. Please try again in a moment.",
      },
      { status: 500 },
    );
  }
}
