import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userRole = await sql`
      SELECT role FROM user_roles WHERE user_id = ${session.user.id}
    `;

    if (userRole.length === 0 || userRole[0].role !== 'admin') {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    const url = new URL(request.url);
    const format = url.searchParams.get('format') || 'csv';

    // Get all transactions with user and category info
    const transactions = await sql`
      SELECT 
        t.id,
        u.email as user_email,
        c.name as category_name,
        t.amount,
        t.description,
        t.payment_mode,
        t.transaction_type,
        t.transaction_date,
        t.created_at
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      JOIN auth_users u ON t.user_id = u.id
      ORDER BY t.created_at DESC
    `;

    if (format === 'csv') {
      // Generate CSV
      const headers = [
        'ID',
        'User Email',
        'Category',
        'Amount',
        'Description',
        'Payment Mode',
        'Type',
        'Transaction Date',
        'Created At'
      ];

      const csvRows = [
        headers.join(','),
        ...transactions.map(t => [
          t.id,
          `"${t.user_email}"`,
          `"${t.category_name}"`,
          t.amount,
          `"${t.description || ''}"`,
          t.payment_mode,
          t.transaction_type,
          t.transaction_date,
          t.created_at
        ].join(','))
      ];

      const csvContent = csvRows.join('\n');

      return new Response(csvContent, {
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': 'attachment; filename="expense_tracker_export.csv"'
        }
      });

    } else if (format === 'pdf') {
      // For PDF, we'll return a simple text-based report
      // In a real application, you'd use a PDF library like puppeteer or jsPDF
      
      const reportContent = `
EXPENSE TRACKER REPORT
Generated on: ${new Date().toLocaleDateString()}

SUMMARY:
Total Transactions: ${transactions.length}
Total Income: ₹${transactions.filter(t => t.transaction_type === 'income').reduce((sum, t) => sum + parseFloat(t.amount), 0).toLocaleString()}
Total Expenses: ₹${transactions.filter(t => t.transaction_type === 'expense').reduce((sum, t) => sum + parseFloat(t.amount), 0).toLocaleString()}

TRANSACTIONS:
${transactions.map(t => `
${t.transaction_date} | ${t.user_email} | ${t.category_name} | ${t.transaction_type === 'income' ? '+' : '-'}₹${parseFloat(t.amount).toLocaleString()} | ${t.payment_mode} | ${t.description || 'No description'}
`).join('')}
      `;

      return new Response(reportContent, {
        headers: {
          'Content-Type': 'text/plain',
          'Content-Disposition': 'attachment; filename="expense_tracker_report.txt"'
        }
      });
    }

    return Response.json({ error: "Invalid format" }, { status: 400 });

  } catch (error) {
    console.error('Error exporting data:', error);
    return Response.json({ error: "Failed to export data" }, { status: 500 });
  }
}